#include<iostream>
#include<algorithm>
int findUniqueNumber(int arr[], int n){
    void sortZeroOne(int arr[], int n){
        void printAllPairs(int arr[], int n){
            pairs<int, int> checkTwoSum(int arr[], int n, int target){
                void checkTwoSumUsingArray(int arr[], int n, int target, int ans[]){
                    void checkTwoSumPrintAllAnswers(int arr[], int n, int target){
                        void printAllTriplets(int arr[], int n){
                            int count =0;
                            for(int i=0; i<n; i++){
                                for(int j=0; j<n; j++){
                                    for(int k=0; k<n; k++){
                                        cout<< arr[i] << " ," << arr[k]<< endl;
                                    }
                                }
                            }
                            cout<< "Total triplets printed:"<< count<<endl;
                        }
                        int main(){
                            int arr[] = {10,20,30,40};
                            int n= 4;
                            printAllTriplets(arr, n);
                        }
                    }
                }
            }
        }
    }
                    
                
            
        
    
    return 0;
